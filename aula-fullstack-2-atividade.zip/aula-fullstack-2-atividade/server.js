import express from "express";
import { fileURLToPath } from "url";
import path from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const port = 8080;
const app = express();

app.use(express.json());

// const tarefas = [
//   { id: 1, tarefa: "Estudar Node.js" },
//   { id: 2, tarefa: "Fazer exercícios" },
//   { id: 3, tarefa: "Tomar café" },
// ];

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/tarefas", (req, res) => {
  res.json(tarefas);
});

app.post("/tarefas", (req, res) => {
  const usuario = req.body.usuario;
});

app.listen(port, () => console.log("Server tá on!"));